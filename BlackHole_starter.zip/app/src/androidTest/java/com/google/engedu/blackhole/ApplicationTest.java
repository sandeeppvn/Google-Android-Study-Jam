package com.google.engedu.blackhole;

import android.app.Application;
import android.test.ApplicationTestCase;

import org.junit.Assert;
import org.junit.Test;

import dalvik.annotation.TestTargetClass;

/**
 * <a href="http://d.android.com/tools/testing/testing_android.html">Testing Fundamentals</a>
 */
public class ApplicationTest extends ApplicationTestCase<Application> {
    public ApplicationTest() {
        super(Application.class);
    }

}