package com.google.engedu.blackhole;


public class BlackHoleTile {
    public int player;
    public int value;

    BlackHoleTile(int player, int value) {
        this.player = player;
        this.value = value;
    }
}
